module.exports = {
    url:"http://localhost/finalproject/"
};