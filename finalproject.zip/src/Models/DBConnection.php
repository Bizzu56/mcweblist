<?php
namespace Bizu\Weblistmc\Models;

use PDO;
use PDOException;

class DBConnection extends PDO
{

    private static $instance;

    private const DB_HOST = '89.213.140.252';
    private const DB_USER = 'u4_LowIq8jqcq';
    private const DB_PASSWORD = 'qNi.P@3dkVovJx0USP4CtuAS';
    private const DB_NAME = 's4_prefinal';

    private function __construct()
    {
        $_dsn = 'mysql:dbname='. self::DB_NAME . ';host=' . self::DB_HOST;

        try{
            parent::__construct($_dsn, self::DB_USER, self::DB_PASSWORD);

            $this->setAttribute(PDO::MYSQL_ATTR_INIT_COMMAND, 'SET NAMES utf8');
            $this->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        } catch (PDOException $e){
            die($e->getMessage());
        }
        
    }

    public static function getInstance():self
    {
        if(self::$instance === null){
            self::$instance = new self();
        }
        return self::$instance;
    }
}