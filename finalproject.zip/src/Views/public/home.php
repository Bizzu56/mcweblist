<?php require_once __DIR__ . "/components/header.php" ?>


<section class="home-section-container">
    
</section>
<script src="./assets/js/home.js"></script>

<?php require_once __DIR__ . "/components/footer.php" ?>
