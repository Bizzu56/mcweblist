<?php require_once __DIR__ . "/../components/header.php" ?>

<section class="server-list-section">
<div class="server-list-container">
    
</div>
</section>

<script src="./assets/js/server-list.js"></script>

<?php require_once __DIR__ . "/../components/footer.php" ?>
