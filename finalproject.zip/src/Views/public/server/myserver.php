<?php require_once __DIR__ . "/../components/header.php" ?>

<section class="server-private-list-section">
<div class="nav-server-create">
    <h1>La liste de tes serveur</h1>
    <a href="?action=servercreate">Ajouter</a>
</div>
<div class="server-private-list-container"></div>
</section>

<script src="./assets/js/server-list.js"></script>

<?php require_once __DIR__ . "/../components/footer.php" ?>
